library(readr)
Xtr = read.csv("Xtr.csv")
Xtr1 = Xtr[, c("List_Year", "Assessed_Value")]
Xte = read.csv("Xte.csv")
Xte1 = Xte[, c("List_Year", "Assessed_Value")]
Ytr = read.csv("Ytr.csv")
