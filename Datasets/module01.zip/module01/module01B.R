Xtr2 = Xtr1
Xte2 = Xte1
mu = mean(c(Xtr2$Assessed_Value, Xte2$Assessed_Value), na.rm = T)

# pred1 - Imputation by filling in mean for assessed value
Xtr2$Assessed_Value[is.na(Xtr2$Assessed_Value)] = mu
Xte2$Assessed_Value[is.na(Xte2$Assessed_Value)] = mu

pred0 = read.csv("pred0.csv")
pred1 = pred0

model = lm(y ~ ., data = data.frame(X = Xtr2, y = Ytr$Sale_Amount))
pred1$Sale_Amount = predict(model, data.frame(X = Xte2))
write.table(pred1, file = "pred1.csv", quote=F, row.names=F, sep = ",")

# pred2 - Imputation by filling in mean by year for assessed value

Xtr3 = Xtr1
Xte3 = Xte1
years = c(Xtr3$List_Year, Xte3$List_Year)
values = c(Xtr2$Assessed_Value, Xte2$Assessed_Value)
for (year in unique(years)) {
  mu = mean(values[years == year], na.rm = T)
  mask = Xtr3$List_Year == year & is.na(Xtr3$Assessed_Value)
  Xtr3$Assessed_Value[mask] = mu
  mask = Xte3$List_Year == year & is.na(Xte3$Assessed_Value)
  Xte3$Assessed_Value[mask] = mu
}

pred2 = pred0

model = lm(y ~ ., data = data.frame(X = Xtr3, y = Ytr$Sale_Amount))
pred2$Sale_Amount = predict(model, data.frame(X = Xte3))
write.table(pred2, file = "pred2.csv", quote=F, row.names=F, sep = ",")